﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Ü203WM_Motorradkonfig
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            List<string> items = new List<string>
            {
                "Harley",
                "Honda",
                "BMW"

            };

            cb_Marke.ItemsSource = items;
            List<string> items2 = new List<string>
            {
                "Kardanwelle",
                "Kette",
                "Zahnriemen"

            };

            cb_Antrieb.ItemsSource = items2;
            List<string> items3 = new List<string>
            {
                "750",
                "1000",
                "1500"

            };

            cb_Hubraum.ItemsSource = items3;
            List<string> items4 = new List<string>
            {
                "70",
                "90",
                "100"

            };

            cb_PS.ItemsSource = items4;
        }

        private void bt_berechnen_Click(object sender, RoutedEventArgs e)
        {
            double PS = Convert.ToDouble(cb_PS.Text), Hubraum = Convert.ToDouble(cb_Hubraum.Text);
            string Marke = cb_Marke.Text, Antrieb = cb_Antrieb.Text, Modell = null;

            if (Hubraum == 1000 && PS == 100 && Marke == "BMW" && Antrieb == "Kardanwelle")
            {
                Modell = "BMW R 1250 RT";
            }
            if (Hubraum == 1000 && PS == 100 && Marke == "BMW" && Antrieb == "Zahnriemen")
            {
                Modell = "BMW R 850 RT";
            }
            if (Hubraum == 1500 && PS == 100 && Marke == "BMW" && Antrieb == "Zahnriemen")
            {
                Modell = "BMW R 1350 RT";
            }
            if (Hubraum == 1000 && PS == 100 && Marke == "BMW" && Antrieb == "Kardanwelle")
            {
                Modell = "BMW S 1000 XR";
            }
            if (Hubraum == 750 && PS == 70 && Marke == "BMW" && Antrieb == "Kardanwelle")
            {
                Modell = "BMW F 750 GS";
            }
            if (Hubraum == 750 && PS == 70 && Marke == "BMW" && Antrieb == "Kette")
            {
                Modell = "BMW F 8150 GS";
            }
            if (Hubraum == 1500 && PS == 90 && Marke == "BMW" && Antrieb == "Kardanwelle")
            {
                Modell = "BMW K 1600 B";
            }
            if (Hubraum == 1500 && PS == 90 && Marke == "BMW" && Antrieb == "Kette")
            {
                Modell = "BMW R 1250 RT";
            }
            if (Hubraum == 750 && PS == 90 && Marke == "BMW" && Antrieb == "Kardanwelle")
            {
                Modell = "BMW F 750 GS";
            }
            if (Hubraum == 750 && PS == 90 && Marke == "BMW" && Antrieb == "Kette")
            {
                Modell = "BMW F 750 GS";
            }
            if (Hubraum == 1000 && PS == 100 && Marke == "Honda" && Antrieb == "Kardanwelle")
            {
                Modell = "Honda Gold Wing";
            }
            if (Hubraum == 1000 && PS == 100 && Marke == "Honda" && Antrieb == "Kette")
            {
                Modell = "Honda CB1000R";
            }
            if (Hubraum == 750 && PS == 70 && Marke == "Honda" && Antrieb == "Kardanwelle")
            {
                Modell = "Honda Gold Wing";
            }
            if (Hubraum == 750 && PS == 70 && Marke == "Honda" && Antrieb == "Kette")
            {
                Modell = "Honda CB1000R";
            }
            if (Hubraum == 1500 && PS == 90 && Marke == "Honda" && Antrieb == "Kardanwelle")
            {
                Modell = "Honda Gold Wing";
            }
            if (Hubraum == 750 && PS == 90 && Marke == "Honda" && Antrieb == "Kardanwelle")
            {
                Modell = "Honda NC750X";
            }
            if (Hubraum == 750 && PS == 90 && Marke == "Honda" && Antrieb == "Kette")
            {
                Modell = "Honda NC750S";
            }
            if (Hubraum == 1000 && PS == 100 && Marke == "Harley" && Antrieb == "Kardanwelle")
            {
                Modell = "Harley-Davidson N34N1";
            }
            if (Hubraum == 1500 && PS == 90 && Marke == "Harley" && Antrieb == "Zahnriemen")
            {
                Modell = "Harley-Davidson Electra B16";
            }
            if (Hubraum == 1500 && PS == 100 && Marke == "Harley" && Antrieb == "Zahnriemen")
            {
                Modell = "Harley-Davidson Sportster Roadster";
            }
            if (Hubraum == 1500 && PS == 70 && Marke == "Harley" && Antrieb == "Zahnriemen")
            {
                Modell = "Harley-Davidson Electra Glide Standard";
            }

            if (Modell == "null")
            {
                Modell = "Gibts net";
            }
            tb_Modell.Text = Modell;
        }

        

        
    }
}